const {
	formatJalaliCalendarDate,
	getJalaliCalendarMonth,
	getJalaliDateParts,
	shiftJalaliCalendarMonth,
} = require("./jalali_calendar");
const { parseJalaliDateInput } = require("./jalali_input");

const PERSIAN_LOCALE = /^fa(?:[-_]|$)/i;
let jalaliCalendarEnabled = false;

frappe.provide("frappe.ui.form");

function isPersianLocale() {
	return PERSIAN_LOCALE.test(frappe.boot?.lang || frappe.boot?.user?.language || "");
}

function formatSelectedDate(date, input) {
	const fieldtype = input.dataset.fieldtype;
	const format = frappe.datetime.get_user_date_fmt().toUpperCase();
	const datetimeFormat =
		fieldtype === "Datetime" ? `${format} ${frappe.datetime.get_user_time_fmt()}` : format;
	return frappe.datetime.format_persian_calendar(date, datetimeFormat);
}

function installPersianDateLocalization() {
	const datetime = frappe.datetime;
	if (typeof datetime.format_persian_calendar === "function") return;

	datetime.format_persian_calendar = (value, format) => {
		const date = value instanceof Date ? value : value?.toDate ? value.toDate() : moment(value).toDate();
		return formatJalaliCalendarDate(date, format);
	};

	const originalStrToUser = datetime.str_to_user?.bind(datetime);
	if (originalStrToUser) {
		datetime.str_to_user = function (value, onlyTime = false, onlyDate = false) {
			const formatted = originalStrToUser(value, onlyTime, onlyDate);
			if (!jalaliCalendarEnabled || !isPersianLocale() || onlyTime || !formatted) return formatted;
			const dateFormat = datetime.get_user_date_fmt().toUpperCase();
			const hasTime = !onlyDate && String(formatted).includes(" ");
			const format = hasTime
				? `${dateFormat} ${datetime.get_user_time_fmt()}`
				: dateFormat;
			const parsed = moment(formatted, format, true).locale("en");
			return parsed.isValid()
				? formatJalaliCalendarDate(parsed.toDate(), format) || formatted
				: formatted;
		};
	}

	const originalUserToStr = datetime.user_to_str?.bind(datetime);
	if (originalUserToStr) {
		datetime.user_to_str = function (value, onlyTime = false) {
			if (!jalaliCalendarEnabled || !isPersianLocale() || onlyTime || !value) {
				return originalUserToStr(value, onlyTime);
			}
			const parsed = parseJalaliDateInput(
				value,
				datetime.get_user_date_fmt().toUpperCase(),
				datetime.get_user_time_fmt(),
				moment,
			);
			return parsed.matched ? parsed.value : originalUserToStr(value, onlyTime);
		};
	}
}

function isoToLocalDate(isoDate, picker) {
	const [year, month, day] = isoDate.split("-").map(Number);
	const selected = picker.selectedDates?.[0];
	const hour = selected?.getHours() ?? Number(picker.timepicker?.hours ?? 0);
	const minute = selected?.getMinutes() ?? Number(picker.timepicker?.minutes ?? 0);
	const second = selected?.getSeconds() ?? Number(picker.timepicker?.seconds ?? 0);
	return new Date(year, month - 1, day, hour, minute, second, 0);
}

function isCellDisabled(cell, picker) {
	const date = isoToLocalDate(cell.isoDate, picker);
	const asDate = (value) => {
		if (value instanceof Date) return value;
		if (typeof value === "string" && value) return frappe.datetime.str_to_obj(value);
		return null;
	};
	const minDate = asDate(picker.opts.minDate);
	const maxDate = asDate(picker.opts.maxDate);
	const dateOnly = (value) => new Date(value.getFullYear(), value.getMonth(), value.getDate()).getTime();
	if (minDate && dateOnly(date) < dateOnly(minDate)) return true;
	if (maxDate && dateOnly(date) > dateOnly(maxDate)) return true;
	const rendered = picker.opts.onRenderCell?.(date, "day");
	return Boolean(rendered?.disabled || String(rendered?.classes || "").split(/\s+/).includes("disabled"));
}

function renderCalendar(picker) {
	if (!picker.jalaliCalendarMonth) {
		const selected = picker.selectedDates?.[0] || picker.date || new Date();
		const persian = getJalaliDateParts(selected);
		if (!persian) return;
		picker.jalaliCalendarMonth = { year: persian.jy, month: persian.jm };
	}

	const content = picker.$datepicker.find(".datepicker--content");
	if (!content.length) return;

	const { year, month } = picker.jalaliCalendarMonth;
	const calendar = getJalaliCalendarMonth(year, month);
	const root = $("<div>", { class: "jalali-calendar", role: "grid", "aria-label": `${calendar.monthName} ${year}` });
	const header = $("<div>", { class: "jalali-calendar__header" });
	const previous = $("<button>", {
		type: "button",
		class: "jalali-calendar__nav",
		"data-direction": "-1",
		"aria-label": "ماه قبل",
	}).text("‹");
	const next = $("<button>", {
		type: "button",
		class: "jalali-calendar__nav",
		"data-direction": "1",
		"aria-label": "ماه بعد",
	}).text("›");
	header.append(previous, $("<div>", { class: "jalali-calendar__title" }).text(`${calendar.monthName} ${year}`), next);
	root.append(header);

	const weekdays = $("<div>", { class: "jalali-calendar__weekdays", role: "row" });
	calendar.weekdays.forEach((weekday) => {
		weekdays.append($("<span>", { role: "columnheader" }).text(weekday));
	});
	root.append(weekdays);

	const selectedDate = picker.selectedDates?.[0];
	const selectedISO = selectedDate
		? `${selectedDate.getFullYear()}-${String(selectedDate.getMonth() + 1).padStart(2, "0")}-${String(selectedDate.getDate()).padStart(2, "0")}`
		: "";
	const today = frappe.datetime.now_date();
	calendar.weeks.forEach((week) => {
		const row = $("<div>", { class: "jalali-calendar__week", role: "row" });
		week.forEach((cell) => {
			const classes = ["jalali-calendar__day"];
			if (!cell.inMonth) classes.push("is-outside-month");
			if (cell.isoDate === selectedISO) classes.push("is-selected");
			if (cell.isoDate === today) classes.push("is-today");
			const disabled = isCellDisabled(cell, picker);
			if (disabled) classes.push("is-disabled");
			const button = $("<button>", {
				type: "button",
				class: classes.join(" "),
				"data-iso-date": cell.isoDate,
				"aria-label": `${cell.persianDay} ${calendar.monthName} ${year}`,
				disabled,
			}).text(String(cell.persianDay));
			row.append(button);
		});
		root.append(row);
	});
	content.empty().append(root);
}

function attachJalaliCalendar(input) {
	if (!jalaliCalendarEnabled || !isPersianLocale()) return;
	const picker = $(input).data("datepicker");
	if (!picker || picker.jalaliCalendarAttached) return;
	picker.jalaliCalendarAttached = true;
	const originalOnShow = picker.opts.onShow;
	const originalOnSelect = picker.opts.onSelect;
	picker.opts.onShow = function (...args) {
		originalOnShow?.apply(this, args);
		picker.jalaliCalendarMonth = null;
		picker.$datepicker.addClass("jalali-datepicker");
		renderCalendar(picker);
	};
	picker.opts.onSelect = function (formattedDate, date, instance) {
		const selectedDates = picker.selectedDates || [];
		if (selectedDates.length) {
			const formattedDates = selectedDates.map((selected) => formatSelectedDate(selected, input));
			const isDateRange = input.dataset.fieldtype === "DateRange";
			const formatted =
				isDateRange && formattedDates.length === 2
					? __("{0} to {1}", formattedDates)
					: formattedDates[0];
			if (formatted) $(input).val(formatted);
		}
		originalOnSelect?.call(this, formattedDate, date, instance);
	};
	picker.$datepicker.on("click", ".jalali-calendar__nav", function () {
		const current = picker.jalaliCalendarMonth;
		picker.jalaliCalendarMonth = shiftJalaliCalendarMonth(
			current.year,
			current.month,
			Number(this.dataset.direction),
		);
		renderCalendar(picker);
	});
	picker.$datepicker.on("click", ".jalali-calendar__day:not(:disabled)", function () {
		picker.selectDate(isoToLocalDate(this.dataset.isoDate, picker));
	});
	picker.$datepicker.on("click", '[data-action="today"]', () => {
		picker.jalaliCalendarMonth = null;
		window.setTimeout(() => renderCalendar(picker), 0);
	});
}

function localizeSelectedInput(input) {
	const picker = $(input).data("datepicker");
	const selectedDates = picker?.selectedDates || [];
	if (!selectedDates.length) return;
	const formattedDates = selectedDates.map((selected) => formatSelectedDate(selected, input));
	const isDateRange = input.dataset.fieldtype === "DateRange";
	const formatted =
		isDateRange && formattedDates.length === 2
			? __("{0} to {1}", formattedDates)
			: formattedDates[0];
	if (formatted) $(input).val(formatted);
}

function attachVisibleFields() {
	if (!jalaliCalendarEnabled || !isPersianLocale()) return;
	$('input[data-fieldtype="Date"], input[data-fieldtype="Datetime"], input[data-fieldtype="DateRange"]').each(function () {
		attachJalaliCalendar(this);
		localizeSelectedInput(this);
	});
}

function enableJalaliCalendar(settings) {
	jalaliCalendarEnabled = Boolean(settings?.custom_enable_shamsi_jalali_calendar);
	if (!jalaliCalendarEnabled) return;
	installPersianDateLocalization();
	frappe.ui.form.on("*", { refresh: attachVisibleFields });
	$(document).on("form-load form-refresh", attachVisibleFields);
	document.addEventListener("focusin", (event) => {
		if (
			event.target.matches?.(
				'input[data-fieldtype="Date"], input[data-fieldtype="Datetime"], input[data-fieldtype="DateRange"]',
			)
		) {
			attachJalaliCalendar(event.target);
			localizeSelectedInput(event.target);
		}
	});
	frappe.require("/assets/jalali_shamsi_datepicker/js/in_words_cleanup.js");
	attachVisibleFields();
}

frappe.call({
	method: "frappe.client.get",
	args: { doctype: "System Settings", name: "System Settings" },
	callback: (response) => enableJalaliCalendar(response.message),
});
