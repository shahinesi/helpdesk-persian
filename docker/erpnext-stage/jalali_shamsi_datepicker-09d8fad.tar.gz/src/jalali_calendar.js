const { jalaaliWeek, toGregorian, toJalaali } = require("jalaali-js");

const DAY_IN_MS = 24 * 60 * 60 * 1000;
const MONTHS = [
	"فروردین",
	"اردیبهشت",
	"خرداد",
	"تیر",
	"مرداد",
	"شهریور",
	"مهر",
	"آبان",
	"آذر",
	"دی",
	"بهمن",
	"اسفند",
];
const WEEKDAYS = ["شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه"];
const WEEKDAYS_SHORT = ["ش", "ی", "د", "س", "چ", "پ", "ج"];

/** Build a Saturday-first six-week grid while keeping each cell Gregorian for Frappe. */
function getJalaliCalendarMonth(year, month) {
	const { saturday } = jalaaliWeek(year, month, 1);
	const first = toGregorian(saturday.jy, saturday.jm, saturday.jd);
	const gridStart = Date.UTC(first.gy, first.gm - 1, first.gd);
	const cells = Array.from({ length: 42 }, (_, index) => {
		const date = new Date(gridStart + index * DAY_IN_MS);
		const gregorian = {
			year: date.getUTCFullYear(),
			month: date.getUTCMonth() + 1,
			day: date.getUTCDate(),
		};
		const persian = toJalaali(gregorian.year, gregorian.month, gregorian.day);
		return {
			...gregorian,
			isoDate: `${gregorian.year}-${String(gregorian.month).padStart(2, "0")}-${String(
				gregorian.day
			).padStart(2, "0")}`,
			persianDay: persian.jd,
			weekday: index % 7,
			inMonth: persian.jy === year && persian.jm === month,
		};
	});

	return {
		year,
		month,
		monthName: MONTHS[month - 1],
		weekdays: WEEKDAYS,
		weeks: Array.from({ length: 6 }, (_, index) => cells.slice(index * 7, index * 7 + 7)),
	};
}

/** Move to an adjacent Jalali month through jalaali-js and Gregorian day stepping. */
function shiftJalaliCalendarMonth(year, month, direction) {
	if (![-1, 1].includes(direction)) throw new RangeError("direction must be -1 or 1");
	const first = toGregorian(year, month, 1);
	const probe = new Date(Date.UTC(first.gy, first.gm - 1, first.gd));
	probe.setUTCDate(probe.getUTCDate() + (direction < 0 ? -1 : 32));
	const next = toJalaali(probe.getUTCFullYear(), probe.getUTCMonth() + 1, probe.getUTCDate());
	return { year: next.jy, month: next.jm };
}

function getJalaliDateParts(date) {
	if (!(date instanceof Date) || Number.isNaN(date.getTime())) return null;
	return toJalaali(date.getFullYear(), date.getMonth() + 1, date.getDate());
}

function formatJalaliCalendarDate(date, format) {
	if (!(date instanceof Date) || Number.isNaN(date.getTime())) return null;
	const persian = getJalaliDateParts(date);
	if (!persian || typeof format !== "string") return null;
	const pad = (value) => String(value).padStart(2, "0");
	const hour24 = date.getHours();
	const hour12 = hour24 % 12 || 12;
	const weekdayIndex = (date.getDay() + 1) % 7;
	const values = {
		YYYY: String(persian.jy),
		YY: String(persian.jy).slice(-2),
		MMMM: MONTHS[persian.jm - 1],
		MMM: MONTHS[persian.jm - 1],
		MM: pad(persian.jm),
		M: String(persian.jm),
		DD: pad(persian.jd),
		D: String(persian.jd),
		dddd: WEEKDAYS[weekdayIndex],
		ddd: WEEKDAYS_SHORT[weekdayIndex],
		dd: WEEKDAYS_SHORT[weekdayIndex],
		d: String(date.getDay()),
		HH: pad(hour24),
		H: String(hour24),
		hh: pad(hour12),
		h: String(hour12),
		mm: pad(date.getMinutes()),
		m: String(date.getMinutes()),
		ss: pad(date.getSeconds()),
		s: String(date.getSeconds()),
		A: hour24 < 12 ? "AM" : "PM",
		a: hour24 < 12 ? "am" : "pm",
	};
	return format.replace(
		/YYYY|YY|MMMM|MMM|MM|M|DD|D|dddd|ddd|dd|d|HH|H|hh|h|mm|m|ss|s|A|a/g,
		(token) => values[token],
	);
}

module.exports = {
	formatJalaliCalendarDate,
	getJalaliCalendarMonth,
	getJalaliDateParts,
	shiftJalaliCalendarMonth,
};
