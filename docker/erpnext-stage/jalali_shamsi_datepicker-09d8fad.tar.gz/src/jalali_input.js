const { digitsArToFa, digitsFaToEn } = require("@persian-tools/persian-tools");
const { isValidJalaaliDate, toGregorian } = require("jalaali-js");

function parseJalaliDateInput(value, dateFormat, timeFormat, moment) {
	const normalized = digitsFaToEn(digitsArToFa(String(value ?? ""))).trim();
	if (!normalized) return { matched: false };

	const hasTime = /\s/.test(normalized);
	const formats = hasTime
		? [`${dateFormat} ${timeFormat}`, `${dateFormat} ${timeFormat.replace(/:ss\b/, "")}`]
		: [dateFormat];
	const parsed = moment(normalized, formats, true).locale("en");
	if (!parsed.isValid()) return { matched: false };

	const year = parsed.year();
	const month = parsed.month() + 1;
	const day = parsed.date();
	if (!isValidJalaaliDate(year, month, day)) {
		return { matched: true, value: "Invalid date" };
	}

	const gregorian = toGregorian(year, month, day);
	const date = `${gregorian.gy}-${String(gregorian.gm).padStart(2, "0")}-${String(
		gregorian.gd,
	).padStart(2, "0")}`;
	return {
		matched: true,
		value: hasTime ? `${date} ${parsed.format("HH:mm:ss")}` : date,
	};
}

module.exports = { parseJalaliDateInput };
