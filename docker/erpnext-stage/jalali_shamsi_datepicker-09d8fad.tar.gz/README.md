# Jalali Shamsi Datepicker for Frappe

This app adds a Jalali calendar view to Frappe `Date` and `Datetime` field pickers when **Enable Shamsi/Jalali Calendar** is enabled in System Settings and the active UI language is Persian.

## Date and input behavior

- Gregorian date and datetime values remain canonical in the Frappe document, API, and database.
- Calendar conversion and Jalali month navigation use the pinned [`jalaali-js`](https://github.com/jalaali/jalaali-js) dependency. The versioned browser bundle includes that package, so builds do not depend on the host Frappe version providing a global copy. The app does not implement calendar conversion or include `persian-date` / `persian-datepicker`.
- When Frappe provides the shared Jalali formatter/parser, the app uses those methods. On stock Frappe versions that do not provide them, it fills the same `frappe.datetime` API using `jalaali-js` and `@persian-tools/persian-tools`; it does not add a second storage or calendar system.
- Persian/Arabic numeral normalization happens only at the accepted date text-input boundary with `digitsFaToEn(digitsArToFa(input))`. Display output remains ASCII/canonical.
- Rendered digits remain ASCII/canonical; Vazirmatn is responsible for their Persian glyph appearance.
- The English locale keeps Frappe's existing Gregorian picker and formatting.
- Datetime selection retains the picker time and delegates timezone handling to Frappe.

## Install and build

Install the app's pinned JavaScript dependencies and build its versioned bundle, then install/build the app in a bench:

```bash
pnpm install --frozen-lockfile
pnpm build
bench get-app https://github.com/Atshan/jalali_shamsi_datepicker
bench --site [site] install-app jalali_shamsi_datepicker
bench build --app jalali_shamsi_datepicker
bench --site [site] migrate
bench --site [site] clear-cache
```

Enable **Enable Shamsi/Jalali Calendar** in System Settings and reload Desk. The bundle is maintained at `jalali_shamsi_datepicker/public/js/jalali_shamsi_datepicker.bundle.js` and is compiled through Frappe's normal app asset build.

## Tests

The tests in `tests/date-conversion.test.cjs` run with `pnpm test`. They cover Jalali year/month boundaries, input normalization, canonical Gregorian outputs, stock/shared Frappe formatter behavior, English regression, ASCII display values, and the `Asia/Tehran` midnight boundary.

Use pnpm 11.25.0 with the checked-in lockfile when building the browser bundle. The package does not declare pnpm in `packageManager`, because Frappe 16 runs app builds through Yarn and rejects a pnpm package-manager declaration.
