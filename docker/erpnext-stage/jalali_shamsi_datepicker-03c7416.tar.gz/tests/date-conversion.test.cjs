const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const vm = require("node:vm");
process.env.TZ = "Asia/Tehran";
const {
	formatJalaliCalendarDate,
	getJalaliCalendarMonth,
	getJalaliDateParts,
	shiftJalaliCalendarMonth,
} = require("../src/jalali_calendar.js");
const { parseJalaliDateInput } = require("../src/jalali_input.js");

const appRoot = path.resolve(__dirname, "..");

test("builds a Saturday-first six-week grid with canonical Gregorian cell values", () => {
	const calendar = getJalaliCalendarMonth(1403, 12);
	assert.equal(calendar.monthName, "اسفند");
	assert.equal(calendar.weeks.length, 6);
	assert.deepEqual(calendar.weeks.map((week) => week.length), [7, 7, 7, 7, 7, 7]);
	assert.equal(calendar.weeks[0][0].weekday, 0);
	const finalDay = calendar.weeks.flat().find((cell) => cell.inMonth && cell.persianDay === 30);
	assert.equal(finalDay.isoDate, "2025-03-20");
	assert.equal(typeof finalDay.persianDay, "number");
	assert.doesNotMatch(String(finalDay.persianDay), /[۰-۹٠-٩]/);
});

test("moves across Esfand/Farvardin and year boundaries through jalaali-js", () => {
	assert.deepEqual(shiftJalaliCalendarMonth(1403, 12, 1), { year: 1404, month: 1 });
	assert.deepEqual(shiftJalaliCalendarMonth(1404, 1, -1), { year: 1403, month: 12 });
	assert.throws(() => shiftJalaliCalendarMonth(1404, 1, 0), RangeError);
});

test("preserves the Tehran civil date across local midnight", () => {
	assert.equal(Intl.DateTimeFormat().resolvedOptions().timeZone, "Asia/Tehran");
	const beforeMidnight = getJalaliDateParts(new Date("2025-03-20T20:29:00Z"));
	const atMidnight = getJalaliDateParts(new Date("2025-03-20T20:30:00Z"));
	assert.deepEqual(beforeMidnight, { jy: 1403, jm: 12, jd: 30 });
	assert.deepEqual(atMidnight, { jy: 1404, jm: 1, jd: 1 });
});

test("returns no Jalali parts for invalid dates", () => {
	assert.equal(getJalaliDateParts(new Date(Number.NaN)), null);
	assert.equal(getJalaliDateParts("2025-03-20"), null);
});

test("formats Persian dates through jalaali-js while keeping rendered digits canonical", () => {
	const formatted = formatJalaliCalendarDate(new Date(2025, 2, 20, 9, 5), "dddd D MMMM YYYY HH:mm");
	assert.equal(formatted, "پنجشنبه 30 اسفند 1403 09:05");
	assert.doesNotMatch(formatted, /[۰-۹٠-٩]/);
});

function mockMoment(value, formats) {
	const source = String(value ?? "");
	const match = source.match(/^(\d{3,4})[-/](\d{1,2})[-/](\d{1,2})(?:\s+(\d{1,2}):(\d{2})(?::(\d{2}))?)?$/);
	const [, yearText, monthText, dayText, hourText = "0", minuteText = "0", secondText = "0"] = match || [];
	const numbers = [yearText, monthText, dayText, hourText, minuteText, secondText].map(Number);
	const [year, month, day, hour, minute, second] = numbers;
	const date = match ? new Date(year, month - 1, day, hour, minute, second) : new Date(Number.NaN);
	const parsed = {
		isValid: () => Boolean(match) && !Number.isNaN(date.getTime()),
		locale() { return this; },
		year: () => year,
		month: () => month - 1,
		date: () => day,
		toDate: () => date,
		format: (format) => format === "HH:mm:ss"
			? [hour, minute, second].map((part) => String(part).padStart(2, "0")).join(":")
			: source,
	};
	return parsed;
}

test("normalizes accepted Persian and Arabic-Indic input before jalaali-js conversion", () => {
	for (const input of ["1405-01-01", "۱۴۰۵-۰۱-۰۱", "١٤٠٥-٠١-٠١"]) {
		assert.deepEqual(
			parseJalaliDateInput(input, "YYYY-MM-DD", "HH:mm:ss", mockMoment),
			{ matched: true, value: "2026-03-21" },
		);
	}
	assert.deepEqual(
		parseJalaliDateInput("۱۴۰۵-۰۱-۰۱ 09:30:05", "YYYY-MM-DD", "HH:mm:ss", mockMoment),
		{ matched: true, value: "2026-03-21 09:30:05" },
	);
	assert.deepEqual(
		parseJalaliDateInput("1404-12-30", "YYYY-MM-DD", "HH:mm:ss", mockMoment),
		{ matched: true, value: "Invalid date" },
	);
});

test("uses the Frappe picker and shared locale parser without a parallel calendar package", () => {
	const hooks = fs.readFileSync(path.join(appRoot, "jalali_shamsi_datepicker/hooks.py"), "utf8");
	const packageJson = fs.readFileSync(path.join(appRoot, "package.json"), "utf8");
	const manifest = fs.readFileSync(path.join(appRoot, "MANIFEST.in"), "utf8");
	const stylesheet = fs.readFileSync(
		path.join(appRoot, "jalali_shamsi_datepicker/public/css/custom.css"),
		"utf8",
	);
	const source = ["src/jalali_shamsi_datepicker.js", "src/jalali_calendar.js", "src/jalali_input.js"]
		.map((file) => fs.readFileSync(path.join(appRoot, file), "utf8"))
		.join("\n");
	const bundle = fs.readFileSync(
		path.join(appRoot, "jalali_shamsi_datepicker/public/js/jalali_shamsi_datepicker.bundle.js"),
		"utf8",
	);
	assert.match(hooks, /jalali_shamsi_datepicker\.bundle\.js/);
	assert.match(packageJson, /"@persian-tools\/persian-tools": "4\.0\.4"/);
	assert.match(manifest, /recursive-include jalali_shamsi_datepicker \*\.woff2/);
	assert.match(stylesheet, /font-feature-settings:\s*"ss01"/);
	assert.match(stylesheet, /html\[dir="rtl"\]\s+body/);
	assert.match(stylesheet, /font-family:\s*Vazirmatn/);
	assert.match(stylesheet, /fonts\/Vazirmatn-wght\.woff2/);
	assert.ok(fs.existsSync(path.join(appRoot, "jalali_shamsi_datepicker/public/fonts/Vazirmatn-wght.woff2")));
	assert.ok(fs.existsSync(path.join(appRoot, "jalali_shamsi_datepicker/public/fonts/OFL.txt")));
	assert.doesNotMatch(hooks, /persian-date(?:picker)?\.min\.js/);
	assert.doesNotMatch(bundle, /require\(["'](?:jalaali-js|\.\/jalali_calendar)["']\)/);
	assert.match(bundle, /format_persian_calendar/);
	assert.match(bundle, /custom_enable_shamsi_jalali_calendar/);
	assert.match(bundle, /PERSIAN_LOCALE = \/\^fa/);
	assert.match(bundle, /function toJalaali\(/);
	assert.match(bundle, /function toGregorian\(/);
	assert.match(source, /digitsFaToEn\(digitsArToFa\(/);
	assert.doesNotMatch(source, /toCalendar\(|persianDate\(|convert_to_english_digits|digitsEnToFa|\.replace\(\/\[۰-۹/);
	assert.doesNotMatch(bundle, /toCalendar\(|persianDate\(/);
});

test("preserves English picker behavior and formats Persian selections through Frappe", () => {
	const bundle = fs.readFileSync(
		path.join(appRoot, "jalali_shamsi_datepicker/public/js/jalali_shamsi_datepicker.bundle.js"),
		"utf8",
	);
	function mount(locale, { sharedFormatter = true, fieldtype = "Date" } = {}) {
		const input = { dataset: { fieldtype }, value: "" };
		let formattedWith;
		let originalSelectCalls = 0;
		const originalShow = () => {};
		const picker = {
			opts: {
				onShow: originalShow,
				onSelect: () => { originalSelectCalls += 1; },
			},
			selectedDates: [new Date(2025, 2, 20)],
			date: new Date(2025, 2, 20),
			$datepicker: {
				on() {},
				addClass() {},
				find() { return { length: 0 }; },
			},
		};
		const document = { addEventListener() {} };
		const $ = (target) => {
			if (typeof target === "string") return { each(callback) { callback.call(input); } };
			if (target === document) return { on() {} };
			return {
				data: (key) => key === "datepicker" ? picker : undefined,
				val(value) {
					if (arguments.length) input.value = value;
					return arguments.length ? this : input.value;
				},
			};
		};
		const datetime = {
			get_user_date_fmt: () => "yyyy-mm-dd",
			get_user_time_fmt: () => "HH:mm:ss",
			str_to_user: (value) => value,
			user_to_str: (value) => value,
		};
		if (sharedFormatter) {
			datetime.format_persian_calendar = (date, format) => {
				formattedWith = { date, format };
				return "1403/12/30";
			};
		}
		const frappe = {
			boot: { lang: locale },
			provide() {},
			call({ callback }) { callback({ message: { custom_enable_shamsi_jalali_calendar: true } }); },
			ui: { form: { on() {} } },
			require() {},
			datetime,
		};
		vm.runInNewContext(bundle, {
			frappe,
			$,
			Date,
			document,
			__: (template, values) => template.replace("{0}", values[0]).replace("{1}", values[1]),
			moment: mockMoment,
			window: { setTimeout() {} },
		});
		return {
			input,
			picker,
			frappe,
			originalShow,
			get formattedWith() { return formattedWith; },
			get originalSelectCalls() { return originalSelectCalls; },
		};
	}

	const english = mount("en");
	assert.equal(english.picker.opts.onShow, english.originalShow);
	assert.equal(english.input.value, "");

	const persian = mount("fa-IR");
	persian.picker.opts.onShow();
	persian.picker.opts.onSelect("", persian.picker.selectedDates[0], persian.picker);
	assert.equal(persian.input.value, "1403/12/30");
	assert.equal(persian.formattedWith.format, "YYYY-MM-DD");
	assert.equal(persian.originalSelectCalls, 1);

	const stockPersian = mount("fa-IR", { sharedFormatter: false });
	stockPersian.picker.opts.onSelect("", stockPersian.picker.selectedDates[0], stockPersian.picker);
	assert.equal(stockPersian.input.value, "1403-12-30");
	assert.equal(
		stockPersian.frappe.datetime.format_persian_calendar(new Date(2025, 2, 20), "YYYY-MM-DD"),
		"1403-12-30",
	);
	assert.equal(stockPersian.frappe.datetime.user_to_str("۱۴۰۳-۱۲-۳۰"), "2025-03-20");

	const stockEnglish = mount("en", { sharedFormatter: false });
	assert.equal(stockEnglish.frappe.datetime.str_to_user("2025-03-20", false, true), "2025-03-20");
	assert.equal(stockEnglish.frappe.datetime.user_to_str("2025-03-20"), "2025-03-20");

	const dateRange = mount("fa-IR", { sharedFormatter: false, fieldtype: "DateRange" });
	dateRange.picker.selectedDates = [new Date(2025, 2, 20), new Date(2025, 2, 21)];
	dateRange.picker.opts.onSelect("", dateRange.picker.selectedDates, dateRange.picker);
	assert.equal(dateRange.input.value, "1403-12-30 to 1404-01-01");
});
